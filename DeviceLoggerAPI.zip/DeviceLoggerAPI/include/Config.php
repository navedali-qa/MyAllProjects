<?php 
	/**
	* Database config variables
	*/
	define("DB_HOST", "192.168.57.1:3306");
	define("DB_USER", "root");
	define("DB_PASSWORD", "");
	define("DB_DATABASE", "360_logica_mobile_logger");
?>