
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;


public class ManageGmailSpam 
{
	private static final Exception exception = null;

	static WebDriver driver;
	static int allMail=0;
	static int count=0;
	static String value1="";
	static String value2="";
	static String result="";

	public static void main(String as[]) throws InterruptedException, FilloException
	{

		Fillo fillo=new Fillo();

		Connection connection=fillo.getConnection("GMAIL_ATMv2_Whitelisting_Accounts__150seedcsv.xlsx");
		String qryString = "Select * from Sheet1";

		Recordset recordset=connection.executeQuery(qryString);

		while(recordset.next())
		{
			String value = recordset.getField("Usable");
			System.out.println("V"+value+"i");
			if(value=="" || value.toLowerCase().contains("Working".toLowerCase()))
			{
				result=manageGmail(recordset.getField("Proxy"), recordset.getField("Email"), recordset.getField("Password"), recordset.getField("Recovery_email"),recordset.getField("KeyWord"));
			}
			if(result.toLowerCase().contains("working")) 
			{
				qryString = "Update Sheet1 Set Usable='Working' where Proxy='"+recordset.getField("Proxy")+"'and Email='"+recordset.getField("Email")+"' and Recovery_email='"+recordset.getField("Recovery_email")+"'";
				connection.executeUpdate(qryString);
			}
			else
			{
				qryString = "Update Sheet1 Set Usable='Blocked' where Proxy='"+recordset.getField("Proxy")+"'and Email='"+recordset.getField("Email")+"' and Recovery_email='"+recordset.getField("Recovery_email")+"'";
				connection.executeUpdate(qryString);
			}
		}

		recordset.close();
		connection.close();
	}

	public static String manageGmail(String proxyString, String email, String password, String recovery_Email, String keywords)
	{
		try
		{
			ChromeOptions options = new ChromeOptions();
					
			options.addArguments("--proxy-server="+proxyString);
			
			driver = new ChromeDriver(options);

			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();

			driver.navigate().to("https://gmail.com");

			enterText("//input[@id='identifierId']", email);

			click("//span[text()='Next']");

			enterText("//input[@name='password']", password);

			click("//span[text()='Next']");

			Thread.sleep(3000);

			if(!driver.getTitle().toLowerCase().contains("inbox"))
			{
				click("//div[text()='Confirm your recovery email']");

				enterText("//input[@id='knowledge-preregistered-email-response']", recovery_Email);

				click("//span[text()='Next']");
			}
			waitForTitle("inbox");

			if(!driver.getTitle().toLowerCase().contains("inbox"))
			{
				System.out.println("ACCOUNT BLOCKED...");
				driver.quit();
				return "Blocked";
			}
			else
			{
				click("//div[@data-tooltip='Show search options']/div");

				click("//div[@data-tooltip='All Mail']/div[2]");

				//click("//div[text()='Spam']");

				enterText("//label[text()='Subject']/../../span[2]/input",keywords);

				click("//div[@data-tooltip='Search Mail']");

				waitForTitle("search results");

				Thread.sleep(2000);

				value1=getText("//div[@data-tooltip='Older']/../div[1]/span/span[2]");	
				allMail = 0;

				do
				{
					allMail = allMail+driver.findElements(By.xpath("//div[@role='main']/div/div/div/table/tbody/tr")).size();

					value2=getText("//div[@data-tooltip='Older']/../div[1]/span/span/span[2]");

					click("//div[@data-tooltip='Older' and not(@aria-disabled)]");

					Thread.sleep(3000);

					count++;
				}while(!value1.equals(value2));

				int index=count;

				while(count>0)
				{
					click("//div[@data-tooltip='Newer' and not(@aria-disabled)]");
					Thread.sleep(2000);
					count--;
				}
				count = 0;

				//System.out.println("TOTAL SIZE : "+allMail);
				if(allMail==0)
				{
					throw exception;
				}
				String[] name=new String[allMail];

				for(int i=0;i<name.length;i++)
				{
					if(count==50)
					{
						click("//div[@data-tooltip='Older' and not(@aria-disabled)]");
						Thread.sleep(2000);
						count=0;
					}
					String tempName=driver.findElement(By.xpath("(//div[@role='main']/div/div/div/table/tbody/tr/td[4]/div[2]/span)["+(count+1)+"]")).getText();

					name[i]=tempName;

					//System.out.println(name[i]);

					count++;
				}

				while(index>0)
				{
					click("//div[@data-tooltip='Select']/div/span");
					click("//div[@data-tooltip='Newer' and not(@aria-disabled)]");
					Thread.sleep(2000);
					index--;
				}

				click("//span[text()='More']");

				click("//div[text()='Not spam']");

				Thread.sleep(4000);

				String[] removedDuplicates = removeDuplicates(name);
				System.out.println(removedDuplicates.length+"\t"+name.length);
				for(int i=0;i<removedDuplicates.length;i++)
				{
					click("//div[@data-tooltip='Show search options']/div");

					if(i==0)
					{
						click("//div[@data-tooltip='All Mail']/div[2]");
						click("//div[text()='Inbox']");
					}

					enterText("//label[text()='From']/../../span[2]/input", removedDuplicates[i]);

					enterText("//label[text()='Subject']/../../span[2]/input",keywords);

					click("//div[@data-tooltip='Search Mail']");

					waitForTitle("search results");
					Thread.sleep(2000);

					int newmail = driver.findElements(By.xpath("//div[@role='main']/div/div/div/table/tbody/tr")).size();

					for(int k=0;k<newmail;k++)
					{
						click("(//div[@role='main']/div/div/div/table/tbody/tr)["+(k+1)+"]");

						Thread.sleep(2000);

						click("//span[text()='More']");

						click("//div[text()='Mark as important']");

						click("//span[text()='More']");

						click("//div[text()='Add star']");

						click("//div[@data-tooltip='More']");

						click("//div[contains(text(),'to Contacts list')]");

						Thread.sleep(2000);

						//System.out.println(driver.getPageSource().contains("The sender has been added to your contacts list."));

						click("//span[text()='Reply']");

						enterText("//div[@aria-label='Message Body']", "THANKS...");

						click("//div[contains(@data-tooltip,'Send')]");

						System.out.println(driver.manage().getCookies());

						Thread.sleep(3000);

						driver.navigate().back();

						Thread.sleep(2000);
					}
				}
				System.out.println("TASKS PERFORMED...");
				return "Working";
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
			driver.quit();
			return "Working";
		}
	}

	public static void enterText(String locator,String text) throws InterruptedException
	{
		Thread.sleep(1000);
		try
		{
			int size = driver.findElements(By.xpath(locator)).size();
			if(size>0)
			{
				driver.findElements(By.xpath(locator)).get(driver.findElements(By.xpath(locator)).size()-1).clear();
				driver.findElements(By.xpath(locator)).get(driver.findElements(By.xpath(locator)).size()-1).sendKeys(text);
			}
		}
		catch(Exception elementNotVisibleException)
		{
			//System.out.println("NO ENTER ACTION PERFORMED... on "+locator);
		}
	}

	public static void click(String locator) throws InterruptedException
	{
		Thread.sleep(1000);
		try
		{
			int size = driver.findElements(By.xpath(locator)).size();
			if(size>0)
			{
				driver.findElements(By.xpath(locator)).get(driver.findElements(By.xpath(locator)).size()-1).click();
			}
		}
		catch(ElementNotInteractableException elementNotInteractableException)
		{
			System.out.println("NO CLICK ACTION PERFORMED... on "+locator);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", driver.findElements(By.xpath(locator)).get(driver.findElements(By.xpath(locator)).size()-1));
		}
	}

	public static void waitForTitle(String title) throws InterruptedException
	{
		int i=0;
		while(!driver.getTitle().toLowerCase().contains(title.toLowerCase())) 
		{
			Thread.sleep(1000);
			if(i>30)
			{
				break;
			}
			i++;
		}
	}

	public static String getText(String locator)
	{
		try 
		{
			return driver.findElements(By.xpath(locator)).get(driver.findElements(By.xpath(locator)).size()-1).getText();
		}
		catch(ElementNotVisibleException elementNotVisibleException)
		{
			//System.out.println("NO ACTION PERFORMED...");
			return "";
		}
	}

	public static String[] removeDuplicates(String[] arr)
	{
		int end = arr.length;

		for (int i = 0; i < end; i++) 
		{
			for (int j = i + 1; j < end; j++) 
			{
				if (arr[i] == arr[j]) 
				{                  
					arr[j] = arr[end-1];
					end--;
					j--;
				}
			}
		}

		String[] whitelist = new String[end];

		System.arraycopy(arr, 0, whitelist, 0, end);
		return whitelist;
	}
}
